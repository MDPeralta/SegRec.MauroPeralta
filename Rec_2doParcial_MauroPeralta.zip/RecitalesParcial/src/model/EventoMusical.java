
package model;

import java.io.Serializable;
import java.time.LocalDate;
import servicio.CSVSerializable;


public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable,Serializable {
        
    private String artista;
    private GeneroMusical generoMusical;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.generoMusical = genero;
    }

    public GeneroMusical getGeneroMusical() {
        return generoMusical;
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + fecha + "," + artista + "," + generoMusical.toString();
    }
    
    public static EventoMusical fromCSV(String archivoCSV) {
        String[] linea = archivoCSV.split(",");
        
        if (linea.length != 5) {
            throw new IllegalArgumentException("Error en el archivo.");
        }
        
        int id = Integer.parseInt(linea[0]);
        String nombre = linea[1];
        LocalDate fecha = LocalDate.parse(linea[2]);
        String artista = linea[3];
        GeneroMusical generoMusical = GeneroMusical.valueOf(linea[4].toUpperCase());
        return new EventoMusical(id, nombre, fecha, artista, generoMusical);
    }
    
    
    
    
}
