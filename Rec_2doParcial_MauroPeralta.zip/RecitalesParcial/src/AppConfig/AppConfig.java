
package AppConfig;

public class AppConfig {
    
    public static final String PATH_ARCHIVO = "src/data";
    public static final String PATH_SER = PATH_ARCHIVO + "/musical.dat";
    public static final String PATH_CSV = PATH_ARCHIVO + "/musical.csv";
}
