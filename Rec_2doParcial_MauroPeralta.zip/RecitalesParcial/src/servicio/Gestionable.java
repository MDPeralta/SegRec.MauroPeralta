
package servicio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Gestionable<T> {
    
    void agregar(T item);
    
    T obtenerEvento(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<T> criterio);
    
    List<T> buscarPorFecha(LocalDate fechaInicio, LocalDate fechaFin);
    
    void ordenar();
    
    void ordenar(Comparator<T> comparator);
    
    void guardarEnBinario(String path);
    
    void cargarDesdeBinario(String path);
    
    void guardarEnCSV(String path);
    
    void cargarDesdeCSV(String path, Function<String, T> funcion);
    
    void paraCadaElemento(Consumer<T> consumidor);
    
    void mostrarTodos();
}
