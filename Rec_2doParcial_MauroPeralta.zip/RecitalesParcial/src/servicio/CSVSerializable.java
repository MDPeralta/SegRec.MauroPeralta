
package servicio;

public interface CSVSerializable {
    
    String toCSV();
}
