
package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;

public class GestorEventos<T extends Evento> implements Gestionable<T>,Serializable {
    
    List<T> lista = new ArrayList<>();

    @Override
    public void agregar(T items) {
        
        if (items == null) {
            throw new NullPointerException("No se puede agregar un objeto nulo.");
        }
        
        lista.add(items);  
    }    

    @Override
    public T obtenerEvento(int indice) {
        validarIndice(indice);
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        lista.remove(indice);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IllegalArgumentException("El indice es invalido");
        }
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        
        for (T item: lista) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        
        return listaFiltrada;
    }

    @Override
    public List<T> buscarPorFecha(LocalDate fechaInicio, LocalDate fechaFin) {
        List<T> rango = new ArrayList<>();
        for (T item: lista) {
            if (!item.getFecha().isBefore(fechaInicio) && !item.getFecha().isAfter(fechaFin)) {
                rango.add(item);
            }
        }
        return rango;
    }

    @Override
    public void ordenar() {
        ordenar((Comparator <T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) {
        lista.sort(comparator);
    }

    @Override
    public void guardarEnBinario(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            
            salida.writeObject(lista);
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            
            lista = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id, nombre, fecha, artista, generoMusical\n");
            for (T item: lista) {
                bw.write(item.toCSV() + "\n");
            }
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) {
        lista.clear();
        
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                lista.add(funcion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Error en archivo.");
        }
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumidor) {
        for (T item: lista) {
            consumidor.accept(item);
        }
    }
   

    @Override
    public void mostrarTodos() {
        if(lista.isEmpty()){
            throw new NoSuchElementException("No hay nada por mostrar, la lista está vacia");
        }else{
            for(T elementos: lista){
                System.out.println(elementos);
            }
        }
    }
}
